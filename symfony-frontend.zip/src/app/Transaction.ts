export class Transaction {

  constructor(public id, public customerId, public amount, public transactionDate, public offset){

  }

}
