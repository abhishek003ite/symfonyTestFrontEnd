import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-transaction',
  templateUrl: './delete-transaction.component.html',
  styleUrls: ['./delete-transaction.component.css']
})
export class DeleteTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
