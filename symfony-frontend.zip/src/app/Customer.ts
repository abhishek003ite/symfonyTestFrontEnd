export class Customer {

  constructor(public id, public name: string, public cnp: string){

  }

}
